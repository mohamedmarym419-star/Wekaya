<?php $title='آراء المستفيدين'; include 'header.php'; ?>
<div class="card">
  <h2>آراء العملاء</h2>
  <div style="margin-top:12px">
    <div class="testimonial">
      <strong>أمينة — العبور</strong>
      <p class="small">"فريق محترف وجاء في نفس اليوم. شكراً لكم على الرعاية." </p>
    </div>
    <div class="testimonial">
      <strong>محمود — القاهرة</strong>
      <p class="small">"نتائج التحاليل وصلت بسرعة وتم الشرح بشكل واضح."</p>
    </div>
  </div>

  <h3 style="margin-top:12px">أضف تقييمك</h3>
  <form action="/contact_process.php" method="post">
    <label>الاسم</label>
    <input type="text" name="name" required>
    <label style="margin-top:8px">تقييمك أو رسالتك</label>
    <textarea name="message" rows="3" required></textarea>
    <input type="hidden" name="service" value="تقييم">
    <div style="margin-top:10px"><button class="btn" type="submit">أرسل</button></div>
  </form>
</div>
<?php include 'footer.php'; ?>