<?php
// contact_process.php
// بسيط: يخزن في CSV ويرسل إيميل إن أمكن
function clean($s){ return trim(strip_tags($s)); }
$name = isset($_POST['name']) ? clean($_POST['name']) : '';
$email = isset($_POST['email']) ? clean($_POST['email']) : '';
$phone = isset($_POST['phone']) ? clean($_POST['phone']) : '';
$service = isset($_POST['service']) ? clean($_POST['service']) : '';
$message = isset($_POST['message']) ? clean($_POST['message']) : '';

if(!$name || !$message){
  header('Location: /contact.php?status=error');
  exit;
}

// prepare CSV storage
$file = __DIR__ . '/data/messages.csv';
if(!is_dir(__DIR__ . '/data')) mkdir(__DIR__ . '/data', 0755, true);
$fh = fopen($file, 'a');
fputcsv($fh, [date('c'), $name, $email, $phone, $service, $message]);
fclose($fh);

// try to send email (may not work on some hosts)
$to = 'info@wqaya.example';
$subject = "طلب/رسالة من $name — $service";
$body = "الاسم: $name\nالبريد: $email\nالهاتف: $phone\nالخدمة: $service\n\n$message\n";
$headers = "From: $email\r\nReply-To: $email\r\nContent-Type: text/plain; charset=utf-8\r\n";
@mail($to, $subject, $body, $headers);

// redirect with success
header('Location: /contact.php?status=ok');
exit;
?>