<?php $title='الرئيسية'; include 'header.php'; ?>
<section class="hero">
  <div class="left">
    <h1>خدمات طبية و تمريضية في المنزل — وسحب التحاليل</h1>
    <p class="small">نقدّم رعاية طبية وتمريضية منزلية متكاملة وسحب عينات وتحاليل مخبرية داخل مصر. فريق مؤهل لضمان راحة المريض وسلامته.</p>
    <p class="small"><strong>المقر:</strong> مدينة العبور، مصر</p>
    <a class="btn" href="/services.php">اطّلع على خدماتنا</a>
  </div>
  <div class="right card">
    <h3>احجز خدمة منزلية</h3>
    <form action="/contact_process.php" method="post">
      <label>الاسم</label>
      <input type="text" name="name" required>
      <label style="margin-top:8px">الهاتف</label>
      <input type="text" name="phone" required>
      <label style="margin-top:8px">الخدمة المطلوبة</label>
      <select name="service" required>
        <option value="تمريض منزلي">تمريض منزلي</option>
        <option value="سحب عينات">سحب عينات وتحاليل</option>
        <option value="رعاية مسنين">رعاية مسنين</option>
        <option value="استشارة طبية">استشارة طبية عن بعد</option>
      </select>
      <label style="margin-top:8px">ملاحظات</label>
      <textarea name="message" rows="3"></textarea>
      <div style="margin-top:10px"><button class="btn" type="submit">أرسل الطلب</button></div>
    </form>
    <p class="small" style="margin-top:8px">أو اتصل بنا على: +20 100 000 0000</p>
  </div>
</section>

<section style="margin-top:18px">
  <div class="card">
    <h2>لماذا تختارنا؟</h2>
    <div class="grid" style="margin-top:12px">
      <div class="card feature"><h3>فريق مؤهل</h3><p class="small">ممرضون وفنيون مرخّصون بخبرة.</p></div>
      <div class="card feature"><h3>مواعيد مرنة</h3><p class="small">نوفر مواعيد مبكّرة ومساءً لتناسبك.</p></div>
      <div class="card feature"><h3>معدات محمولة</h3><p class="small">أجهزة وآلات تحليل متنقلة لمزيد من الدقة.</p></div>
      <div class="card feature"><h3>سلامة المرضى</h3><p class="small">معايير صارمة لمكافحة العدوى.</p></div>
    </div>
  </div>
</section>

<?php include 'footer.php'; ?>