<?php $title='تواصل'; include 'header.php'; ?>
<div class="grid" style="grid-template-columns:1fr 360px;gap:16px">
  <div class="card">
    <h2>تواصل معنا</h2>
    <form action="/contact_process.php" method="post">
      <label>الاسم</label>
      <input type="text" name="name" required>
      <label style="margin-top:8px">البريد الإلكتروني</label>
      <input type="email" name="email" required>
      <label style="margin-top:8px">الهاتف</label>
      <input type="text" name="phone">
      <label style="margin-top:8px">الخدمة المطلوبة</label>
      <select name="service">
        <option>استعلام عام</option>
        <option>حجز خدمة منزلية</option>
        <option>سحب عينات</option>
        <option>تقييم</option>
      </select>
      <label style="margin-top:8px">الرسالة</label>
      <textarea name="message" rows="5" required></textarea>
      <div style="margin-top:10px"><button class="btn" type="submit">أرسل</button></div>
    </form>
  </div>

  <div class="card">
    <h3>اشترك بالقائمة البريدية</h3>
    <form action="/subscribe_process.php" method="post">
      <label>الاسم</label>
      <input type="text" name="name" required>
      <label style="margin-top:8px">البريد الإلكتروني</label>
      <input type="email" name="email" required>
      <div style="margin-top:10px"><button class="btn" type="submit">اشترك</button></div>
    </form>

    <h3 style="margin-top:12px">معلومات</h3>
    <p class="small"><strong>العنوان:</strong> مدينة العبور، القاهرية، مصر</p>
    <p class="small"><strong>هاتف:</strong> +20 100 000 0000</p>
    <p class="small"><strong>البريد:</strong> info@wqaya.example</p>
  </div>
</div>
<?php include 'footer.php'; ?>