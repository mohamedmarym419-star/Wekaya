<?php
function clean($s){ return trim(strip_tags($s)); }
$name = isset($_POST['name']) ? clean($_POST['name']) : '';
$email = isset($_POST['email']) ? clean($_POST['email']) : '';

if(!$email){
  header('Location: /contact.php?sub=error');
  exit;
}

$file = __DIR__ . '/data/subscribers.csv';
if(!is_dir(__DIR__ . '/data')) mkdir(__DIR__ . '/data', 0755, true);
$exists = file_exists($file);
$fh = fopen($file, 'a');
fputcsv($fh, [date('c'), $name, $email]);
fclose($fh);

// try to send a confirmation email (may not work)
$to = $email;
$subject = "شكراً للاشتراك — وقاية للخدمات الطبية المنزلية";
$body = "شكراً $name على الاشتراك. سنوافيك بالتحديثات قريبًا.";
$headers = "From: info@wqaya.example\r\nContent-Type: text/plain; charset=utf-8\r\n";
@mail($to, $subject, $body, $headers);

header('Location: /contact.php?sub=ok');
exit;
?>