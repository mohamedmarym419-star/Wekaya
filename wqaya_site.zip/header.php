<?php
$site_title = "وقاية للخدمات الطبية المنزلية";
$company_city = "مدينة العبور، مصر";
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title><?= isset($title) ? $title . ' — ' . $site_title : $site_title ?></title>
  <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
  <header class="header">
    <div class="container" style="display:flex;align-items:center;justify-content:space-between">
      <div style="display:flex;gap:12px;align-items:center">
        <div class="logo">وقاية</div>
        <div>
          <div style="font-weight:800"><?= $site_title ?></div>
          <div class="small">مقرنا: <?= $company_city ?></div>
        </div>
      </div>
      <nav>
        <a href="/index.php">الرئيسية</a>
        <a href="/services.php">خدماتنا</a>
        <a href="/awareness.php">التوعية الصحية</a>
        <a href="/testimonials.php">آراء المستفيدين</a>
        <a href="/contact.php">تواصل</a>
      </nav>
    </div>
  </header>
  <main class="container" style="padding-top:18px">
