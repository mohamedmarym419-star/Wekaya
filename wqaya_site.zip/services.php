<?php $title='خدماتنا'; include 'header.php'; ?>
<div class="card">
  <h2>قائمة الخدمات</h2>
  <div class="grid" style="margin-top:12px">
    <div class="card">
      <h3>تمريض منزلي</h3>
      <p class="small">غسيل، تغيير ضمادات، إعطاء أدوية عن طريق الوريد، متابعة جروح.</p>
    </div>
    <div class="card">
      <h3>سحب عينات وتحاليل</h3>
      <p class="small">سحب عينات دم وبول وبصاق، نقله للمختبرات المعتمدة، وإرسال النتائج إلكترونيًا.</p>
    </div>
    <div class="card">
      <h3>رعاية مسنين</h3>
      <p class="small">مساعدة يومية، إعطاء أدوية، دعم تغذية، ومتابعة طبية.</p>
    </div>
    <div class="card">
      <h3>استشارات طبية</h3>
      <p class="small">تنسيق زيارات أطباء اختصاص عند الحاجة واستشارات عن بُعد.</p>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>