نسخة جاهزة للنشر لموقع "وقاية للخدمات الطبية المنزلية"

محتويات المشروع:
- index.php - الصفحة الرئيسية
- services.php - صفحة الخدمات
- awareness.php - مقالات التوعية
- testimonials.php - آراء المستفيدين
- contact.php - صفحة تواصل/اشتراك
- contact_process.php - باك-إند بلغة PHP لمعالجة الفورم وحفظ الرسائل في data/messages.csv
- subscribe_process.php - حفظ المشتركين في data/subscribers.csv
- header.php / footer included_snippets
- assets/style.css - CSS رئيسي
- assets/images/placeholder.svg - صورة مكان مبدئي

متطلبات النشر:
1. استضافة تدعم PHP (نسخة 7.0+). 
2. ارفع كامل المجلد إلى جذر الموقع public_html أو www.
3. تأكد أن مجلد /data قابل للكتابة بواسطة الويب (chmod 755 أو 775 حسب الاستضافة).
4. لتفعيل استقبال البريد، تأكد من إعدادات mail() على الاستضافة أو بدّل ارسال البريد لخدمة SMTP عبر PHPMailer.

ملاحظات أمنية:
- الملفات تخزن نصوصًا من المستخدم. في بيئة إنتاجيّة يُنصح بتعزيز عمليات التحقق ومنع الرسائل المكررة.
- استبدل عناوين البريد الافتراضية info@wqaya.example لبريدكم الحقيقي.
