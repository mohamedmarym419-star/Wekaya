
  </main>
  <footer class="container">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap">
      <div class="small">© <?= date('Y') ?> وقاية للخدمات الطبية المنزلية — كل الحقوق محفوظة</div>
      <div class="small">صُنع بحب لخدمات الرعاية المنزلية</div>
    </div>
  </footer>
</body>
</html>
