<?php $title='التوعية الصحية'; include 'header.php'; ?>
<div class="card">
  <h2>مقالات توعوية</h2>
  <article style="margin-top:12px">
    <h3>أهمية غسل اليدين</h3>
    <p class="small">غسل اليدين بالماء والصابون 20 ثانية يقلل من نقل العدوى. طريقة صحيحة: بين الأصابع وتحت الأظافر.</p>
    <a class="btn" href="#more1" onclick="alert('إضافة مقال كامل لاحقاً — هذه نسخة مبسطة')">اقرأ المزيد</a>
  </article>
  <article style="margin-top:12px">
    <h3>كيفية تجهيز مكان سحب العينات في المنزل</h3>
    <p class="small">جهّز طاولة نظيفة، موفرة للضوء، وتأكد من راحة المريض أثناء السحب. الفريق سيستخدم أدوات معقمة.</p>
  </article>
  <article style="margin-top:12px">
    <h3>نصائح للعناية بالمسنّين</h3>
    <p class="small">المتابعة الدورية للأدوية، التغذية، والتمارين البسيطة تساعد على تحسين جودة الحياة.</p>
  </article>
</div>
<?php include 'footer.php'; ?>